document.addEventListener("DOMContentLoaded", function () {
    // Funkcja do dzwonienia
    window.callUs = function () {
        const phoneNumber = "+48 123 456 789";
        window.location.href = `tel:${phoneNumber}`;  // Inicjowanie połączenia telefonicznego
    };

    // Funkcja do wysyłania e-maila
    window.sendEmail = function () {
        const email = "kontakt@restauracja.pl";
        window.location.href = `mailto:${email}`;  // Otwiera domyślny klient e-mail
    };
});