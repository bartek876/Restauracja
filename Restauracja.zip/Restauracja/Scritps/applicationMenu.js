document.addEventListener("DOMContentLoaded", () => {
  const menuIcon = document.querySelector(".header__menu img"); // Ikona menu
  const menuOpen = document.querySelector(".header__menu--open"); // Menu rozwijane

  menuIcon.addEventListener("click", () => {
    menuOpen.style.display = menuOpen.style.display === "block" ? "none" : "block";
  });
});