// Pobieramy wszystkie pola ilości
const inputs = document.querySelectorAll('.mainOnline input[type="number"]');
const totalPriceElement = document.getElementById('total-price');

// Funkcja do obliczania całkowitego kosztu
function calculateTotal() {
    let total = 0;

    inputs.forEach(input => {
        const quantity = parseInt(input.value) || 0; // Ilość danego produktu
        const price = parseFloat(input.dataset.price); // Cena produktu
        total += quantity * price; // Dodajemy do całkowitego kosztu
    });

    totalPriceElement.textContent = total.toFixed(2); // Wyświetlenie wyniku
}

// Nasłuchiwanie zmian w polach ilości
inputs.forEach(input => {
    input.addEventListener('input', calculateTotal);
});

// Inicjalizacja obliczenia przy ładowaniu strony
calculateTotal();

document.addEventListener("DOMContentLoaded", () => {
    const orderButton = document.querySelector(".order-button");
    const thankYouMessage = document.getElementById("thank-you-message");

    // Po kliknięciu przycisku "Złóż zamówienie" pokazuje się komunikat
    orderButton.addEventListener("click", () => {
        thankYouMessage.style.display = "block";
    });
});